// $ANTLR 3.1.3 Mar 17, 2009 19:23:44 src/Swush.g 2009-07-29 18:12:19

/**
 * Automatically generated code, do not edit!
 * To modify, make changes to Swush.g (ANTLR file).
 */
package net.firefang.swush.parser;


import org.antlr.runtime.*;
import java.util.Stack;
import java.util.List;
import java.util.ArrayList;

public class SwushLexer extends Lexer {
    public static final int WORD=5;
    public static final int MULTILINE_COMMENT=7;
    public static final int WS=9;
    public static final int T__12=12;
    public static final int T__11=11;
    public static final int SINGLELINE_COMMENT=6;
    public static final int T__13=13;
    public static final int T__10=10;
    public static final int QSTRING=4;
    public static final int COMMENT=8;
    public static final int EOF=-1;

    // delegates
    // delegators

    public SwushLexer() {;} 
    public SwushLexer(CharStream input) {
        this(input, new RecognizerSharedState());
    }
    public SwushLexer(CharStream input, RecognizerSharedState state) {
        super(input,state);

    }
    public String getGrammarFileName() { return "src/Swush.g"; }

    // $ANTLR start "T__10"
    public final void mT__10() throws RecognitionException {
        try {
            int _type = T__10;
            int _channel = DEFAULT_TOKEN_CHANNEL;
            // src/Swush.g:11:7: ( '@swush 1.0' )
            // src/Swush.g:11:9: '@swush 1.0'
            {
            match("@swush 1.0"); 


            }

            state.type = _type;
            state.channel = _channel;
        }
        finally {
        }
    }
    // $ANTLR end "T__10"

    // $ANTLR start "T__11"
    public final void mT__11() throws RecognitionException {
        try {
            int _type = T__11;
            int _channel = DEFAULT_TOKEN_CHANNEL;
            // src/Swush.g:12:7: ( '{' )
            // src/Swush.g:12:9: '{'
            {
            match('{'); 

            }

            state.type = _type;
            state.channel = _channel;
        }
        finally {
        }
    }
    // $ANTLR end "T__11"

    // $ANTLR start "T__12"
    public final void mT__12() throws RecognitionException {
        try {
            int _type = T__12;
            int _channel = DEFAULT_TOKEN_CHANNEL;
            // src/Swush.g:13:7: ( '}' )
            // src/Swush.g:13:9: '}'
            {
            match('}'); 

            }

            state.type = _type;
            state.channel = _channel;
        }
        finally {
        }
    }
    // $ANTLR end "T__12"

    // $ANTLR start "T__13"
    public final void mT__13() throws RecognitionException {
        try {
            int _type = T__13;
            int _channel = DEFAULT_TOKEN_CHANNEL;
            // src/Swush.g:14:7: ( ':' )
            // src/Swush.g:14:9: ':'
            {
            match(':'); 

            }

            state.type = _type;
            state.channel = _channel;
        }
        finally {
        }
    }
    // $ANTLR end "T__13"

    // $ANTLR start "COMMENT"
    public final void mCOMMENT() throws RecognitionException {
        try {
            int _type = COMMENT;
            int _channel = DEFAULT_TOKEN_CHANNEL;
            // src/Swush.g:55:9: ( ( SINGLELINE_COMMENT | MULTILINE_COMMENT ) )
            // src/Swush.g:55:11: ( SINGLELINE_COMMENT | MULTILINE_COMMENT )
            {
            // src/Swush.g:55:11: ( SINGLELINE_COMMENT | MULTILINE_COMMENT )
            int alt1=2;
            int LA1_0 = input.LA(1);

            if ( (LA1_0=='#') ) {
                alt1=1;
            }
            else if ( (LA1_0=='/') ) {
                int LA1_2 = input.LA(2);

                if ( (LA1_2=='/') ) {
                    alt1=1;
                }
                else if ( (LA1_2=='*') ) {
                    alt1=2;
                }
                else {
                    NoViableAltException nvae =
                        new NoViableAltException("", 1, 2, input);

                    throw nvae;
                }
            }
            else {
                NoViableAltException nvae =
                    new NoViableAltException("", 1, 0, input);

                throw nvae;
            }
            switch (alt1) {
                case 1 :
                    // src/Swush.g:55:12: SINGLELINE_COMMENT
                    {
                    mSINGLELINE_COMMENT(); 

                    }
                    break;
                case 2 :
                    // src/Swush.g:55:33: MULTILINE_COMMENT
                    {
                    mMULTILINE_COMMENT(); 

                    }
                    break;

            }

             _channel = HIDDEN; 

            }

            state.type = _type;
            state.channel = _channel;
        }
        finally {
        }
    }
    // $ANTLR end "COMMENT"

    // $ANTLR start "WS"
    public final void mWS() throws RecognitionException {
        try {
            int _type = WS;
            int _channel = DEFAULT_TOKEN_CHANNEL;
            // src/Swush.g:56:4: ( ( '\\t' | ' ' | '\\r' | '\\n' | '\\u000C' )+ )
            // src/Swush.g:56:6: ( '\\t' | ' ' | '\\r' | '\\n' | '\\u000C' )+
            {
            // src/Swush.g:56:6: ( '\\t' | ' ' | '\\r' | '\\n' | '\\u000C' )+
            int cnt2=0;
            loop2:
            do {
                int alt2=2;
                int LA2_0 = input.LA(1);

                if ( ((LA2_0>='\t' && LA2_0<='\n')||(LA2_0>='\f' && LA2_0<='\r')||LA2_0==' ') ) {
                    alt2=1;
                }


                switch (alt2) {
            	case 1 :
            	    // src/Swush.g:
            	    {
            	    if ( (input.LA(1)>='\t' && input.LA(1)<='\n')||(input.LA(1)>='\f' && input.LA(1)<='\r')||input.LA(1)==' ' ) {
            	        input.consume();

            	    }
            	    else {
            	        MismatchedSetException mse = new MismatchedSetException(null,input);
            	        recover(mse);
            	        throw mse;}


            	    }
            	    break;

            	default :
            	    if ( cnt2 >= 1 ) break loop2;
                        EarlyExitException eee =
                            new EarlyExitException(2, input);
                        throw eee;
                }
                cnt2++;
            } while (true);

             _channel = HIDDEN; 

            }

            state.type = _type;
            state.channel = _channel;
        }
        finally {
        }
    }
    // $ANTLR end "WS"

    // $ANTLR start "WORD"
    public final void mWORD() throws RecognitionException {
        try {
            int _type = WORD;
            int _channel = DEFAULT_TOKEN_CHANNEL;
            // src/Swush.g:57:7: ( ( 'a' .. 'z' | 'A' .. 'Z' | '0' .. '9' | '~' | '!' | '@' | '$' | '%' | '^' | '&' | '*' | '(' | ')' | '_' | '+' | '=' | '-' | '\\\\' | '/' | '.' )+ )
            // src/Swush.g:57:8: ( 'a' .. 'z' | 'A' .. 'Z' | '0' .. '9' | '~' | '!' | '@' | '$' | '%' | '^' | '&' | '*' | '(' | ')' | '_' | '+' | '=' | '-' | '\\\\' | '/' | '.' )+
            {
            // src/Swush.g:57:8: ( 'a' .. 'z' | 'A' .. 'Z' | '0' .. '9' | '~' | '!' | '@' | '$' | '%' | '^' | '&' | '*' | '(' | ')' | '_' | '+' | '=' | '-' | '\\\\' | '/' | '.' )+
            int cnt3=0;
            loop3:
            do {
                int alt3=2;
                int LA3_0 = input.LA(1);

                if ( (LA3_0=='!'||(LA3_0>='$' && LA3_0<='&')||(LA3_0>='(' && LA3_0<='+')||(LA3_0>='-' && LA3_0<='9')||LA3_0=='='||(LA3_0>='@' && LA3_0<='Z')||LA3_0=='\\'||(LA3_0>='^' && LA3_0<='_')||(LA3_0>='a' && LA3_0<='z')||LA3_0=='~') ) {
                    alt3=1;
                }


                switch (alt3) {
            	case 1 :
            	    // src/Swush.g:
            	    {
            	    if ( input.LA(1)=='!'||(input.LA(1)>='$' && input.LA(1)<='&')||(input.LA(1)>='(' && input.LA(1)<='+')||(input.LA(1)>='-' && input.LA(1)<='9')||input.LA(1)=='='||(input.LA(1)>='@' && input.LA(1)<='Z')||input.LA(1)=='\\'||(input.LA(1)>='^' && input.LA(1)<='_')||(input.LA(1)>='a' && input.LA(1)<='z')||input.LA(1)=='~' ) {
            	        input.consume();

            	    }
            	    else {
            	        MismatchedSetException mse = new MismatchedSetException(null,input);
            	        recover(mse);
            	        throw mse;}


            	    }
            	    break;

            	default :
            	    if ( cnt3 >= 1 ) break loop3;
                        EarlyExitException eee =
                            new EarlyExitException(3, input);
                        throw eee;
                }
                cnt3++;
            } while (true);


            }

            state.type = _type;
            state.channel = _channel;
        }
        finally {
        }
    }
    // $ANTLR end "WORD"

    // $ANTLR start "QSTRING"
    public final void mQSTRING() throws RecognitionException {
        try {
            int _type = QSTRING;
            int _channel = DEFAULT_TOKEN_CHANNEL;
            // src/Swush.g:58:9: ( '\"' ( '\\\\\\\\' | '\\\\\"' | ~ ( '\"' | '\\\\' ) )* '\"' )
            // src/Swush.g:58:11: '\"' ( '\\\\\\\\' | '\\\\\"' | ~ ( '\"' | '\\\\' ) )* '\"'
            {
            match('\"'); 
            // src/Swush.g:58:15: ( '\\\\\\\\' | '\\\\\"' | ~ ( '\"' | '\\\\' ) )*
            loop4:
            do {
                int alt4=4;
                int LA4_0 = input.LA(1);

                if ( (LA4_0=='\\') ) {
                    int LA4_2 = input.LA(2);

                    if ( (LA4_2=='\\') ) {
                        alt4=1;
                    }
                    else if ( (LA4_2=='\"') ) {
                        alt4=2;
                    }


                }
                else if ( ((LA4_0>='\u0000' && LA4_0<='!')||(LA4_0>='#' && LA4_0<='[')||(LA4_0>=']' && LA4_0<='\uFFFF')) ) {
                    alt4=3;
                }


                switch (alt4) {
            	case 1 :
            	    // src/Swush.g:58:17: '\\\\\\\\'
            	    {
            	    match("\\\\"); 


            	    }
            	    break;
            	case 2 :
            	    // src/Swush.g:58:26: '\\\\\"'
            	    {
            	    match("\\\""); 


            	    }
            	    break;
            	case 3 :
            	    // src/Swush.g:58:34: ~ ( '\"' | '\\\\' )
            	    {
            	    if ( (input.LA(1)>='\u0000' && input.LA(1)<='!')||(input.LA(1)>='#' && input.LA(1)<='[')||(input.LA(1)>=']' && input.LA(1)<='\uFFFF') ) {
            	        input.consume();

            	    }
            	    else {
            	        MismatchedSetException mse = new MismatchedSetException(null,input);
            	        recover(mse);
            	        throw mse;}


            	    }
            	    break;

            	default :
            	    break loop4;
                }
            } while (true);

            match('\"'); 

            }

            state.type = _type;
            state.channel = _channel;
        }
        finally {
        }
    }
    // $ANTLR end "QSTRING"

    // $ANTLR start "SINGLELINE_COMMENT"
    public final void mSINGLELINE_COMMENT() throws RecognitionException {
        try {
            // src/Swush.g:60:29: ( ( '#' | '//' ) (~ ( '\\n' | '\\n\\r' ) )* ( '\\n' | '\\n\\r' ) )
            // src/Swush.g:60:32: ( '#' | '//' ) (~ ( '\\n' | '\\n\\r' ) )* ( '\\n' | '\\n\\r' )
            {
            // src/Swush.g:60:32: ( '#' | '//' )
            int alt5=2;
            int LA5_0 = input.LA(1);

            if ( (LA5_0=='#') ) {
                alt5=1;
            }
            else if ( (LA5_0=='/') ) {
                alt5=2;
            }
            else {
                NoViableAltException nvae =
                    new NoViableAltException("", 5, 0, input);

                throw nvae;
            }
            switch (alt5) {
                case 1 :
                    // src/Swush.g:60:33: '#'
                    {
                    match('#'); 

                    }
                    break;
                case 2 :
                    // src/Swush.g:60:39: '//'
                    {
                    match("//"); 


                    }
                    break;

            }

            // src/Swush.g:60:45: (~ ( '\\n' | '\\n\\r' ) )*
            loop6:
            do {
                int alt6=2;
                int LA6_0 = input.LA(1);

                if ( ((LA6_0>='\u0000' && LA6_0<='\t')||(LA6_0>='\u000B' && LA6_0<='\uFFFF')) ) {
                    alt6=1;
                }


                switch (alt6) {
            	case 1 :
            	    // src/Swush.g:60:46: ~ ( '\\n' | '\\n\\r' )
            	    {
            	    if ( (input.LA(1)>='\u0000' && input.LA(1)<='\t')||(input.LA(1)>='\u000B' && input.LA(1)<='\uFFFF') ) {
            	        input.consume();

            	    }
            	    else {
            	        MismatchedSetException mse = new MismatchedSetException(null,input);
            	        recover(mse);
            	        throw mse;}


            	    }
            	    break;

            	default :
            	    break loop6;
                }
            } while (true);

            // src/Swush.g:60:65: ( '\\n' | '\\n\\r' )
            int alt7=2;
            int LA7_0 = input.LA(1);

            if ( (LA7_0=='\n') ) {
                int LA7_1 = input.LA(2);

                if ( (LA7_1=='\r') ) {
                    alt7=2;
                }
                else {
                    alt7=1;}
            }
            else {
                NoViableAltException nvae =
                    new NoViableAltException("", 7, 0, input);

                throw nvae;
            }
            switch (alt7) {
                case 1 :
                    // src/Swush.g:60:66: '\\n'
                    {
                    match('\n'); 

                    }
                    break;
                case 2 :
                    // src/Swush.g:60:73: '\\n\\r'
                    {
                    match("\n\r"); 


                    }
                    break;

            }


            }

        }
        finally {
        }
    }
    // $ANTLR end "SINGLELINE_COMMENT"

    // $ANTLR start "MULTILINE_COMMENT"
    public final void mMULTILINE_COMMENT() throws RecognitionException {
        try {
            // src/Swush.g:61:27: ( '/*' ( options {greedy=false; } : . )* '*/' )
            // src/Swush.g:61:28: '/*' ( options {greedy=false; } : . )* '*/'
            {
            match("/*"); 

            // src/Swush.g:61:33: ( options {greedy=false; } : . )*
            loop8:
            do {
                int alt8=2;
                int LA8_0 = input.LA(1);

                if ( (LA8_0=='*') ) {
                    int LA8_1 = input.LA(2);

                    if ( (LA8_1=='/') ) {
                        alt8=2;
                    }
                    else if ( ((LA8_1>='\u0000' && LA8_1<='.')||(LA8_1>='0' && LA8_1<='\uFFFF')) ) {
                        alt8=1;
                    }


                }
                else if ( ((LA8_0>='\u0000' && LA8_0<=')')||(LA8_0>='+' && LA8_0<='\uFFFF')) ) {
                    alt8=1;
                }


                switch (alt8) {
            	case 1 :
            	    // src/Swush.g:61:60: .
            	    {
            	    matchAny(); 

            	    }
            	    break;

            	default :
            	    break loop8;
                }
            } while (true);

            match("*/"); 


            }

        }
        finally {
        }
    }
    // $ANTLR end "MULTILINE_COMMENT"

    public void mTokens() throws RecognitionException {
        // src/Swush.g:1:8: ( T__10 | T__11 | T__12 | T__13 | COMMENT | WS | WORD | QSTRING )
        int alt9=8;
        alt9 = dfa9.predict(input);
        switch (alt9) {
            case 1 :
                // src/Swush.g:1:10: T__10
                {
                mT__10(); 

                }
                break;
            case 2 :
                // src/Swush.g:1:16: T__11
                {
                mT__11(); 

                }
                break;
            case 3 :
                // src/Swush.g:1:22: T__12
                {
                mT__12(); 

                }
                break;
            case 4 :
                // src/Swush.g:1:28: T__13
                {
                mT__13(); 

                }
                break;
            case 5 :
                // src/Swush.g:1:34: COMMENT
                {
                mCOMMENT(); 

                }
                break;
            case 6 :
                // src/Swush.g:1:42: WS
                {
                mWS(); 

                }
                break;
            case 7 :
                // src/Swush.g:1:45: WORD
                {
                mWORD(); 

                }
                break;
            case 8 :
                // src/Swush.g:1:50: QSTRING
                {
                mQSTRING(); 

                }
                break;

        }

    }


    protected DFA9 dfa9 = new DFA9(this);
    static final String DFA9_eotS =
        "\1\uffff\1\10\4\uffff\1\10\3\uffff\10\10\1\5\2\10\1\uffff";
    static final String DFA9_eofS =
        "\26\uffff";
    static final String DFA9_minS =
        "\1\11\1\163\4\uffff\1\52\3\uffff\1\167\2\0\1\165\3\0\1\163\1\41"+
        "\1\150\1\40\1\uffff";
    static final String DFA9_maxS =
        "\1\176\1\163\4\uffff\1\57\3\uffff\1\167\2\uffff\1\165\3\uffff\1"+
        "\163\1\176\1\150\1\40\1\uffff";
    static final String DFA9_acceptS =
        "\2\uffff\1\2\1\3\1\4\1\5\1\uffff\1\6\1\7\1\10\13\uffff\1\1";
    static final String DFA9_specialS =
        "\13\uffff\1\3\1\1\1\uffff\1\2\1\0\1\4\5\uffff}>";
    static final String[] DFA9_transitionS = {
            "\2\7\1\uffff\2\7\22\uffff\1\7\1\10\1\11\1\5\3\10\1\uffff\4\10"+
            "\1\uffff\2\10\1\6\12\10\1\4\2\uffff\1\10\2\uffff\1\1\32\10\1"+
            "\uffff\1\10\1\uffff\2\10\1\uffff\32\10\1\2\1\uffff\1\3\1\10",
            "\1\12",
            "",
            "",
            "",
            "",
            "\1\14\4\uffff\1\13",
            "",
            "",
            "",
            "\1\15",
            "\41\5\1\16\2\5\3\16\1\5\4\16\1\5\15\16\3\5\1\16\2\5\33\16\1"+
            "\5\1\16\1\5\2\16\1\5\32\16\3\5\1\16\uff81\5",
            "\41\5\1\20\2\5\3\20\1\5\2\20\1\17\1\20\1\5\15\20\3\5\1\20\2"+
            "\5\33\20\1\5\1\20\1\5\2\20\1\5\32\20\3\5\1\20\uff81\5",
            "\1\21",
            "\41\5\1\16\2\5\3\16\1\5\4\16\1\5\15\16\3\5\1\16\2\5\33\16\1"+
            "\5\1\16\1\5\2\16\1\5\32\16\3\5\1\16\uff81\5",
            "\41\5\1\20\2\5\3\20\1\5\2\20\1\17\1\20\1\5\2\20\1\22\12\20"+
            "\3\5\1\20\2\5\33\20\1\5\1\20\1\5\2\20\1\5\32\20\3\5\1\20\uff81"+
            "\5",
            "\41\5\1\20\2\5\3\20\1\5\2\20\1\17\1\20\1\5\15\20\3\5\1\20\2"+
            "\5\33\20\1\5\1\20\1\5\2\20\1\5\32\20\3\5\1\20\uff81\5",
            "\1\23",
            "\1\20\2\uffff\3\20\1\uffff\2\20\1\17\1\20\1\uffff\15\20\3\uffff"+
            "\1\20\2\uffff\33\20\1\uffff\1\20\1\uffff\2\20\1\uffff\32\20"+
            "\3\uffff\1\20",
            "\1\24",
            "\1\25",
            ""
    };

    static final short[] DFA9_eot = DFA.unpackEncodedString(DFA9_eotS);
    static final short[] DFA9_eof = DFA.unpackEncodedString(DFA9_eofS);
    static final char[] DFA9_min = DFA.unpackEncodedStringToUnsignedChars(DFA9_minS);
    static final char[] DFA9_max = DFA.unpackEncodedStringToUnsignedChars(DFA9_maxS);
    static final short[] DFA9_accept = DFA.unpackEncodedString(DFA9_acceptS);
    static final short[] DFA9_special = DFA.unpackEncodedString(DFA9_specialS);
    static final short[][] DFA9_transition;

    static {
        int numStates = DFA9_transitionS.length;
        DFA9_transition = new short[numStates][];
        for (int i=0; i<numStates; i++) {
            DFA9_transition[i] = DFA.unpackEncodedString(DFA9_transitionS[i]);
        }
    }

    class DFA9 extends DFA {

        public DFA9(BaseRecognizer recognizer) {
            this.recognizer = recognizer;
            this.decisionNumber = 9;
            this.eot = DFA9_eot;
            this.eof = DFA9_eof;
            this.min = DFA9_min;
            this.max = DFA9_max;
            this.accept = DFA9_accept;
            this.special = DFA9_special;
            this.transition = DFA9_transition;
        }
        public String getDescription() {
            return "1:1: Tokens : ( T__10 | T__11 | T__12 | T__13 | COMMENT | WS | WORD | QSTRING );";
        }
        public int specialStateTransition(int s, IntStream _input) throws NoViableAltException {
            IntStream input = _input;
        	int _s = s;
            switch ( s ) {
                    case 0 : 
                        int LA9_15 = input.LA(1);

                        s = -1;
                        if ( (LA9_15=='/') ) {s = 18;}

                        else if ( (LA9_15=='*') ) {s = 15;}

                        else if ( (LA9_15=='!'||(LA9_15>='$' && LA9_15<='&')||(LA9_15>='(' && LA9_15<=')')||LA9_15=='+'||(LA9_15>='-' && LA9_15<='.')||(LA9_15>='0' && LA9_15<='9')||LA9_15=='='||(LA9_15>='@' && LA9_15<='Z')||LA9_15=='\\'||(LA9_15>='^' && LA9_15<='_')||(LA9_15>='a' && LA9_15<='z')||LA9_15=='~') ) {s = 16;}

                        else if ( ((LA9_15>='\u0000' && LA9_15<=' ')||(LA9_15>='\"' && LA9_15<='#')||LA9_15=='\''||LA9_15==','||(LA9_15>=':' && LA9_15<='<')||(LA9_15>='>' && LA9_15<='?')||LA9_15=='['||LA9_15==']'||LA9_15=='`'||(LA9_15>='{' && LA9_15<='}')||(LA9_15>='\u007F' && LA9_15<='\uFFFF')) ) {s = 5;}

                        else s = 8;

                        if ( s>=0 ) return s;
                        break;
                    case 1 : 
                        int LA9_12 = input.LA(1);

                        s = -1;
                        if ( (LA9_12=='*') ) {s = 15;}

                        else if ( ((LA9_12>='\u0000' && LA9_12<=' ')||(LA9_12>='\"' && LA9_12<='#')||LA9_12=='\''||LA9_12==','||(LA9_12>=':' && LA9_12<='<')||(LA9_12>='>' && LA9_12<='?')||LA9_12=='['||LA9_12==']'||LA9_12=='`'||(LA9_12>='{' && LA9_12<='}')||(LA9_12>='\u007F' && LA9_12<='\uFFFF')) ) {s = 5;}

                        else if ( (LA9_12=='!'||(LA9_12>='$' && LA9_12<='&')||(LA9_12>='(' && LA9_12<=')')||LA9_12=='+'||(LA9_12>='-' && LA9_12<='9')||LA9_12=='='||(LA9_12>='@' && LA9_12<='Z')||LA9_12=='\\'||(LA9_12>='^' && LA9_12<='_')||(LA9_12>='a' && LA9_12<='z')||LA9_12=='~') ) {s = 16;}

                        else s = 8;

                        if ( s>=0 ) return s;
                        break;
                    case 2 : 
                        int LA9_14 = input.LA(1);

                        s = -1;
                        if ( ((LA9_14>='\u0000' && LA9_14<=' ')||(LA9_14>='\"' && LA9_14<='#')||LA9_14=='\''||LA9_14==','||(LA9_14>=':' && LA9_14<='<')||(LA9_14>='>' && LA9_14<='?')||LA9_14=='['||LA9_14==']'||LA9_14=='`'||(LA9_14>='{' && LA9_14<='}')||(LA9_14>='\u007F' && LA9_14<='\uFFFF')) ) {s = 5;}

                        else if ( (LA9_14=='!'||(LA9_14>='$' && LA9_14<='&')||(LA9_14>='(' && LA9_14<='+')||(LA9_14>='-' && LA9_14<='9')||LA9_14=='='||(LA9_14>='@' && LA9_14<='Z')||LA9_14=='\\'||(LA9_14>='^' && LA9_14<='_')||(LA9_14>='a' && LA9_14<='z')||LA9_14=='~') ) {s = 14;}

                        else s = 8;

                        if ( s>=0 ) return s;
                        break;
                    case 3 : 
                        int LA9_11 = input.LA(1);

                        s = -1;
                        if ( (LA9_11=='!'||(LA9_11>='$' && LA9_11<='&')||(LA9_11>='(' && LA9_11<='+')||(LA9_11>='-' && LA9_11<='9')||LA9_11=='='||(LA9_11>='@' && LA9_11<='Z')||LA9_11=='\\'||(LA9_11>='^' && LA9_11<='_')||(LA9_11>='a' && LA9_11<='z')||LA9_11=='~') ) {s = 14;}

                        else if ( ((LA9_11>='\u0000' && LA9_11<=' ')||(LA9_11>='\"' && LA9_11<='#')||LA9_11=='\''||LA9_11==','||(LA9_11>=':' && LA9_11<='<')||(LA9_11>='>' && LA9_11<='?')||LA9_11=='['||LA9_11==']'||LA9_11=='`'||(LA9_11>='{' && LA9_11<='}')||(LA9_11>='\u007F' && LA9_11<='\uFFFF')) ) {s = 5;}

                        else s = 8;

                        if ( s>=0 ) return s;
                        break;
                    case 4 : 
                        int LA9_16 = input.LA(1);

                        s = -1;
                        if ( (LA9_16=='*') ) {s = 15;}

                        else if ( (LA9_16=='!'||(LA9_16>='$' && LA9_16<='&')||(LA9_16>='(' && LA9_16<=')')||LA9_16=='+'||(LA9_16>='-' && LA9_16<='9')||LA9_16=='='||(LA9_16>='@' && LA9_16<='Z')||LA9_16=='\\'||(LA9_16>='^' && LA9_16<='_')||(LA9_16>='a' && LA9_16<='z')||LA9_16=='~') ) {s = 16;}

                        else if ( ((LA9_16>='\u0000' && LA9_16<=' ')||(LA9_16>='\"' && LA9_16<='#')||LA9_16=='\''||LA9_16==','||(LA9_16>=':' && LA9_16<='<')||(LA9_16>='>' && LA9_16<='?')||LA9_16=='['||LA9_16==']'||LA9_16=='`'||(LA9_16>='{' && LA9_16<='}')||(LA9_16>='\u007F' && LA9_16<='\uFFFF')) ) {s = 5;}

                        else s = 8;

                        if ( s>=0 ) return s;
                        break;
            }
            NoViableAltException nvae =
                new NoViableAltException(getDescription(), 9, _s, input);
            error(nvae);
            throw nvae;
        }
    }
 

}