package net.firefang.swush;

import java.io.IOException;
import java.io.StringReader;
import java.util.ArrayList;
import java.util.List;

import net.firefang.swush.selector.SelectorLexer;
import net.firefang.swush.selector.SelectorParser;

import org.antlr.runtime.ANTLRReaderStream;
import org.antlr.runtime.RecognitionException;
import org.antlr.runtime.TokenRewriteStream;
import org.antlr.runtime.tree.Tree;

public class Selector
{
	private String m_selectors[];
	
	public Selector(String selectorStr) throws SwushException
	{
		try
		{
			Tree selector = (Tree) loadSelectorParser(selectorStr).selector().getTree();
			if (selector != null)
			{
				int nc = selector.getChildCount();
				if (nc == 0) // single
				{
					m_selectors = new String[] {selector.getText()};
				}
				else
				{
					m_selectors = new String[nc];
					for(int i=0;i<nc;i++)
					{
						m_selectors[i] = selector.getChild(i).getText();
					}
				}
			}
		} catch (RecognitionException e)
		{
			throw new SwushException(e);
		}
	}
	
	private static SelectorParser loadSelectorParser(String str) throws RecognitionException
	{
		try
		{
			SelectorLexer lexer = new SelectorLexer(new ANTLRReaderStream(new StringReader(str)));
			TokenRewriteStream tokens = new TokenRewriteStream(lexer);
			return new SelectorParser(tokens);
		} 
		catch (IOException e)
		{
			// can't really happen, we read from memory
			throw new RuntimeException(e);
		}
	}
	
	public List<Swush> select(Swush s)
	{
		if (m_selectors == null)
		{
			ArrayList<Swush> res = new ArrayList<Swush>();
			if (s.isDummyRoot()) 
				res.addAll(s.getChildren());
			else 
				res.add(s);
			
			return res;
		}
		else
		{
			return select(s, 0);
		}
	}
	
	private List<Swush> select(Swush swush, int index)
	{
		List<Swush> res = new ArrayList<Swush>();
		String select = m_selectors[index];
		
		
		if (swush.isDummyRoot())
		{
			for(Swush child : swush.getChildren())
			{
				res.addAll(select(child, index));
			}
		}
		else
		{
			if (index == m_selectors.length - 1) // last level
			{
				if ((swush.getName()== null && select.equals(""))  || (swush.getName() != null && swush.getName().equals(select)))
					res.add(swush);
			}
			else
			{
				if ((swush.getName() == null && select.equals(""))  ||  
						(swush.getName() != null && swush.getName().equals(select)))
				{
					for(Swush child : swush.getChildren())
					{
						res.addAll(select(child, index+1));
					}
				}
			}
		}
		return res;
	}
	
	@Override
	public String toString()
	{
		StringBuffer sb = new StringBuffer();
		for(int i = 0;i<m_selectors.length;i++)
		{
			sb.append(m_selectors[i]);
			if (i < m_selectors.length - 1) sb.append(".");
		}
		return sb.toString();
	}
}
