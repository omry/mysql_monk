package net.firefang.swush;

import java.io.BufferedReader;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.StringReader;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import net.firefang.swush.parser.SwushLexer;
import net.firefang.swush.parser.SwushParser;
import net.firefang.swush.parser.SwushParser.header_return;

import org.antlr.runtime.ANTLRInputStream;
import org.antlr.runtime.ANTLRReaderStream;
import org.antlr.runtime.RecognitionException;
import org.antlr.runtime.Token;
import org.antlr.runtime.TokenRewriteStream;
import org.antlr.runtime.tree.CommonTree;
import org.antlr.runtime.tree.Tree;

/**
 * todo:
 * fix case of file with only comments (line 1:0 extraneous input '//key:value' expecting EOF)
 * check DOS newlines
 */
public class Swush
{
	public static enum NodeType
	{
		NODE,PAIR,UNKNOWN
	}
	
	private NodeType m_type = NodeType.UNKNOWN;
	
	/**
	 * Parent swush node
	 */
	private Swush m_parent;
	
	/**
	 * Name of this node/array/pair
	 */
	private String m_name;
	
	/**
	 * Value of a pair, relevant if m_type is PAIR
	 */
	private SwushString m_value;
	

	/**
	 * Children of this node, relevant if type is NODE
	 */
	private List<Swush> m_children;
	
	/**
	 * Maps node name to List of swush child nodes with the same name.
	 * relevant if type is NODE  
	 */
	private Map<String, List<Swush>> m_map;
	
	
	public static Swush empty()
	{
		return new Swush((String)null);
	}
	
	public static Swush pair(String key, String value)
	{
		return new Swush(key, new SwushString(value));
	}
	
	public static Swush node(String name)
	{
		return new Swush(name);
	}
	
	public static Swush fromString(String str) throws SwushException
	{
		try
		{
			SwushParser p = loadParser(str);
			Tree tree = (Tree) p.swush_file().getTree();
			return new Swush(tree);
		}
		catch(RecognitionException e)
		{
			throw new SwushException(e);
		} 
		catch (IOException e)
		{
			// can't really happen, reading from memory.
			throw new RuntimeException(e);
		}
	}
		
	
	public Swush(InputStream in) throws IOException, SwushException
	{
		try
		{
			SwushParser p = loadParser(in);
			Tree tree = (Tree) p.swush_file().getTree();
			init(tree);
		} 
		catch (RecognitionException e)
		{
			throw new SwushException(e);
		}
	}
	
	public Swush(File file) throws IOException, SwushException
	{
		try
		{
			SwushParser p = loadParser(file);
			Tree tree = (Tree) p.swush_file().getTree();
			init(tree);
		} 
		catch (RecognitionException e)
		{
			throw new SwushException(e);
		}
	}
	
	private Swush(Tree tree) throws SwushException
	{
		init(tree);
	}
	
	public Swush selectFirst(String selector) throws SwushException 
	{
		List<Swush> select = select(this, selector);
		if (select.size() == 0) return null;
		return select.get(0);
	}
	
	public List<Swush> select(String selector) throws SwushException 
	{
		return select(this, selector);
	}
	
	static List<Swush> select(Swush swush, String selectorStr) throws SwushException
	{
		Selector  selector = new Selector(selectorStr);
		return selector.select(swush);
	}
	
	
	private void init(Tree tree) throws SwushException
	{
		if (tree == null) 
			return;
		
		m_name = tree.getText();
		if (isKeyVal(tree))
		{
			m_type = NodeType.PAIR;
			m_value = new SwushString(tree.getChild(1));
		}
		else
		{
			m_type = NodeType.NODE;
			boolean dummyRoot = m_name == null;
			if (tree.getChildCount() == 0) // single string
			{
				// nop
			}
			else
			if (dummyRoot || tree.getChild(0).getText().equals("{")) // dummy root or swush node
			{
				m_children = new ArrayList<Swush>();
				m_map = new HashMap<String, List<Swush>>();
				Swush swush;
				int cc = tree.getChildCount();
				int start = dummyRoot ? 0 : 1;
				int end = dummyRoot ? cc : cc -1;
				for(int i = start;i<end;i++)
				{
					Tree child = tree.getChild(i);
					if (isKeyVal(child))
					{
						String key = fixString(child.getText());
						swush = new Swush(key, new SwushString(child.getChild(1)));
					}
					else
					{
						swush = new Swush(child);
					}
					add(swush);
				}
			}
			else
				throw new SwushException("Unexpected node type " + tree);
		}
	}

	private String fixString(String s)
	{
		if (s.startsWith("'") || s.startsWith("\"")) // strip quotes 
			s = s.substring(1, s.length()- 1);
		s = s.replaceAll("\\\\\"", "\"");
		return s;
	}

	private static boolean isKeyVal(Tree child)
	{
		return child.getChildCount() > 0 && child.getChild(0).getText().equals(":");
	}

	private static SwushParser loadParser(File file) throws IOException, SwushException, RecognitionException
	{
		FileInputStream fin = null;
		try
		{
			fin = new FileInputStream(file);
			String encoding = validateHeader(fin);
			return loadParser(fin, encoding);
		}
		finally
		{
			if (fin != null) fin.close();
		}		
	}
	
	private static SwushParser loadParser(InputStream in) throws IOException, SwushException, RecognitionException
	{
		String encoding = validateHeader(in);
		return loadParser(in, encoding);
	}

	private static String validateHeader(InputStream in) throws IOException,
			RecognitionException, SwushException
	{
		String headerStr;
		if (!in.markSupported())
		{
			ByteArrayOutputStream bout = new ByteArrayOutputStream();
			int c;
	        while ((c = in.read()) != -1)
	        {
	        	if (c == '\n') break;
	            bout.write((byte)c);
	        }
	        
	        ByteArrayInputStream in2 = new ByteArrayInputStream(bout.toByteArray());
			headerStr = new BufferedReader(new InputStreamReader(in2)).readLine();
		}
		else
		{
			in.mark(1000);
			headerStr = new BufferedReader(new InputStreamReader(in)).readLine();
			in.reset();
			in.skip(headerStr.length());
		}
		
		return validateHeader(headerStr);
	}
	

	private static String validateHeader(String headerStr) throws RecognitionException, SwushException, IOException
	{
		header_return header = loadParser(headerStr).header();
		CommonTree tree = (CommonTree) header.getTree();
		String hs;
		if (tree.getText() == null)
			hs = tree.getChild(0).getText();
		else
			hs = tree.getText();

		if (!hs.equals("@swush 1.0"))
			throw new IOException("Invalid header");
		String encoding = "utf-8";
		if (tree.getChildCount() > 1)
			encoding = tree.getChild(1).getText();
		return encoding;
	}


	
	
	private static SwushParser loadParser(String swushString) throws IOException, SwushException
	{
		SwushLexer lexer = new SwushLexer(new ANTLRReaderStream(new StringReader(swushString)));
		TokenRewriteStream tokens = new TokenRewriteStream(lexer);
		return new SwushParser(tokens);
	}
	
	private static SwushParser loadParser(InputStream in, String encoding) throws IOException, SwushException
	{
		SwushLexer lexer = new SwushLexer(new ANTLRInputStream(in, encoding));
		TokenRewriteStream tokens = new TokenRewriteStream(lexer);
		return new SwushParser(tokens);
	}

	public static void main(String[] args) throws IOException, SwushException
	{
		if (args.length == 0)
		{
			System.err.println("Usage : " + Swush.class.getName() + " [swush-file [selector]]");
		}
		else
		{
			File file = new File(args[0]);
			Swush swush = new Swush(file);
			String selector = "";
			if (args.length > 1)
			{
				selector = args[1];
			}
			List<Swush> list = swush.select(selector);
			for(Swush m : list) 
				System.out.println(m);
		}
	}

	@Override
	public String toString()
	{
		return swushToString(this, 0);
	}
	
	public static String swushToString(Swush swush, int indent)
	{
		if (swush.isEmpty()) return "*EMPTY*";
		StringBuffer sb = new StringBuffer();
		for(int x =0;x<indent;x++) 
			sb.append("    ");

		if (swush.isPair())
		{
			sb.append(swush.m_name).append(" : ").append(swush.m_value);
		}
		else
		if (swush.isNode())
		{
			if (!swush.isDummyRoot())
			{
				sb.append(swush.m_name);
				if (swush.m_children != null)
				{
					sb.append("\n");
					for(int x =0;x<indent;x++) 
						sb.append("    ");
					sb.append("{\n");
				}
			}
			else indent--;
			
			if (swush.m_children != null)
			{
				for(int i=0;i<swush.m_children.size();i++)
				{
					Swush child = swush.m_children.get(i);
					sb.append(swushToString(child, indent + 1));
					if (i < swush.m_children.size() - 1) 
						sb.append("\n");
				}
			}
//			else
//			{
//				sb.append("{}");
//			}
			
			if (!swush.isDummyRoot())
			{
				if (swush.m_children != null)
				{
					sb.append("\n");
					for(int x =0;x<indent;x++) 
						sb.append("    ");
					
					sb.append("}");
				}
			}
		}
		else
			sb.append("*UNKNOWN TYPE*");
		
		
		return sb.toString();
	}
	
	public String getSelector()
	{
		return m_parent != null && !m_parent.isDummyRoot() ? m_parent.getSelector() + "." + m_name :  (m_name != null ? m_name : "");
	}
	
	public void replace(Swush swush)
	{
		if (getType() == NodeType.PAIR)
		{
			if (getName().equals(swush.getName()))
			{
				m_value = swush.m_value;
			}
		}
		else
		{
			if (m_map == null) 
				m_map = new HashMap<String, List<Swush>>();
			else
			{
				if (m_map.containsKey(swush.getName()))
				{
					remove(swush.getName());
				}
			}
			add(swush);
		}
	}
	
	public void remove(String name)
	{
		List<Swush> list = m_map.remove(name);
		for(Swush s : list)
		{
			m_children.remove(s);
		}
	}

	public void add(Swush swush)
	{
		if (m_children == null)
		{
			m_children = new ArrayList<Swush>();
		}
		m_children.add(swush);
		swush.m_parent = this;
		List<Swush> list = m_map.get(swush.m_name);
		if (list == null) m_map.put(swush.m_name, list = new ArrayList<Swush>());
		list.add(swush);
		m_map.put(swush.m_name, list);
	}
	
	@Override
	public boolean equals(Object obj)
	{
		if (obj instanceof Swush)
		{
			Swush swush = (Swush) obj;
			return equals(this, swush);
		}
		
		return false;
	}

	private static boolean equals(Swush s1, Swush s2)
	{
		if (s1.getType() != s2.getType()) return false;
		if (!s1.m_name.equals(s2.m_name)) return false;
		if (s1.isPair())
		{
			if (s1.m_value.equals(s2.m_value)) 
				return true;
		}
		else
		if (s1.isNode())
		{
			if (s1.m_children == null && s2.m_children == null) return true;
			if (s1.m_children == null && s2.m_children != null || s1.m_children != null && s2.m_children == null) return false;
			if (s1.m_children.size() != s2.m_children.size()) return false;
			for(int i = 0;i<s1.m_children.size();i++)
			{
				Swush c1 = s1.m_children.get(i);
				Swush c2 = s2.m_children.get(i);
				if (!equals(c1, c2)) return false;
			}
			
			return true;
		}
			
		return false;
	}

	public boolean isEmpty()
	{
		return m_name == null && m_children == null;
	}
	
	public boolean isDummyRoot()
	{
		return m_name == null && m_children != null;
	}
	
	public static String treeToString(Tree tree, String tokens[])
	{
		return treeToString(tree, tokens, true);
	}
	
	public static String treeToString(Tree tree, String tokens[], boolean printType)
	{
		return treeToString(tree, 0, tokens, printType);
	}

	public static String treeToString(Tree tree, int indent, String tokens[], boolean printType)
	{
		StringBuffer sb = new StringBuffer();
		for(int x =0;x<indent;x++) 
			sb.append("    ");
		sb.append(tree.getText() + (printType ? " : " + typeStr(tree.getType(), tokens)  : "")+ "\n");
		int childCount = tree.getChildCount();
		if (childCount > 0)
		{
			for(int x =0;x<indent;x++) 
				sb.append("    ");
			sb.append("{\n");
		}
			
		for(int i=0;i<childCount;i++)
		{
			Tree child = tree.getChild(i);
			sb.append(treeToString(child, indent + 1, tokens, printType));
		}
		
		if (childCount > 0)
		{
			for(int x =0;x<indent;x++) 
				sb.append("    ");
			sb.append("}\n");
		}
		
		
		return sb.toString();
	}
	
	static String typeStr(Tree tree, String tokens[])
	{
		return typeStr(tree.getType(), tokens);
	}

	static String typeStr(int type, String tokens[])
	{
		if (type < 0 || type >= tokens.length)
			return "Unknown ("+type+")";
		return type != -1 ? tokens[type] + ": " : "";
	}

	public String getName()
	{
		return m_name;
	}

	public List<Swush> getChildren()
	{
		return m_children;
	}
	
	public int numChildren()
	{
		return m_children != null ? m_children.size() : 0;
	}
	
	public Swush getChildren(int index)
	{
		return m_children.get(index);
	}
	
	public NodeType getType()
	{
		return m_type;
	}
	
	public boolean isPair()
	{
		return m_type == NodeType.PAIR;
	}
	
	public boolean isNode()
	{
		return m_type == NodeType.NODE;
	}
	
	public boolean isString()
	{
		return m_type == NodeType.NODE && m_children == null;
	}
	
	/**
	 * Constructs a node Swush
	 * @param name node name
	 */
	private Swush(String name)
	{
		m_type = NodeType.NODE;
		m_name = name;
		m_children = null; // will be initialized when the first child is added
		m_map = new HashMap<String, List<Swush>>();
	}
	
	/**
	 * Constructs a pair Swush
	 * @param name
	 * @param value
	 */
	private Swush(String name, SwushString value)
	{
		m_type = NodeType.PAIR;
		m_name = name;
		m_value = value;
	}
	
	private static class SwushString
	{
		public static enum ValueType
		{
			WORD,QSTRING,UNKNOWN
		}
		
		ValueType m_type;
		String m_value;
		
		public SwushString(Tree valueNode)
		{
			init(valueNode.getType(), valueNode.getText());
		}
		
		public SwushString(String value) 
		{
			try
			{
				// auto quote strings if they contain whitespace 
				if ((!value.startsWith("\"") && !value.endsWith("\"")))
					if(value.contains(" ") || value.contains("\t") || value.contains(":"))
						value = "\"" + value + "\"";
					
				SwushLexer lexer = new SwushLexer(new ANTLRReaderStream(new StringReader(value)));
				Token token = lexer.nextToken();
				init(token.getType(), token.getText());
			}
			catch (IOException e)
			{
				e.printStackTrace();
			}			
		}

		private void init(int type, String text)
		{
			if (type == SwushParser.QSTRING)
			{
				m_type = ValueType.QSTRING;
			}
			else
			if (type == SwushParser.WORD)
			{
				m_type = ValueType.WORD;
			}
			else
				throw new IllegalArgumentException("Unsupported value type " + typeStr(type, SwushParser.tokenNames));
			
			m_value = text;
		}
		
		@Override
		public String toString()
		{
			switch(m_type)
			{
			case QSTRING:
				return m_value;
			case WORD:
			default:
				return m_value;
			}
		}

		@Override
		public int hashCode()
		{
			final int prime = 31;
			int result = 1;
			result = prime * result
					+ ((m_type == null) ? 0 : m_type.hashCode());
			result = prime * result
					+ ((m_value == null) ? 0 : m_value.hashCode());
			return result;
		}

		@Override
		public boolean equals(Object obj)
		{
			if (this == obj)
				return true;
			if (obj == null)
				return false;
			if (getClass() != obj.getClass())
				return false;
			SwushString other = (SwushString) obj;
			if (m_type == null)
			{
				if (other.m_type != null)
					return false;
			} else if (!m_type.equals(other.m_type))
				return false;
			if (m_value == null)
			{
				if (other.m_value != null)
					return false;
			} else if (!m_value.equals(other.m_value))
				return false;
			return true;
		}
	}

	public Swush firstChild(String name)
	{
		List<Swush> list = m_map.get(name);
		if (list == null) return null;
		return list.get(0);
	}
	
	public String selectProperty(String selector) throws SwushException
	{
		return selectProperty(selector, null);
	}
	
	public String selectProperty(String selector, String _default) throws SwushException
	{
		List<Swush> list = select(selector);
		if (list == null || list.size() == 0) return _default;
		return list.get(0).getTextValue();
	}
	
	
	public int selectIntProperty(String selector) throws SwushException
	{
		String s = selectProperty(selector);
		if (s == null) throw new SwushException(s + " not found");
		return Integer.parseInt(s);
	}
	
	public int selectIntProperty(String selector, int _default) throws SwushException
	{
		return Integer.parseInt(selectProperty(selector, ""+ _default));
	}
	
	public long selectLongProperty(String selector) throws SwushException
	{
		String s = selectProperty(selector);
		if (s == null) throw new SwushException(s + " not found");
		return Long.parseLong(s);
	}
	
	public long selectLongProperty(String selector, long _default) throws SwushException
	{
		return Long.parseLong(selectProperty(selector, ""+ _default));
	}

	public float selectFloatProperty(String selector) throws SwushException
	{
		String s = selectProperty(selector);
		if (s == null) throw new SwushException(s + " not found");
		return Float.parseFloat(s);
	}
	
	public float selectFloatProperty(String selector, float _default) throws SwushException
	{
		return Float.parseFloat(selectProperty(selector, ""+ _default));
	}
	
	public double selectDoubleProperty(String selector) throws SwushException
	{
		String s = selectProperty(selector);
		if (s == null) throw new SwushException(s + " not found");
		return Double.parseDouble(s);
	}
	
	public double selectDoubleproperty(String selector, double _default) throws SwushException
	{
		return Double.parseDouble(selectProperty(selector, ""+ _default));
	}	

	public boolean selectBoolean(String selector) throws SwushException
	{
		String s = selectProperty(selector);
		if (s == null) throw new SwushException(s + " not found");
		return Boolean.valueOf(s);
	}
	
	public boolean selectBoolean(String selector, boolean _default) throws SwushException
	{
		return Boolean.valueOf(selectProperty(selector, ""+ _default));
	}
	
	
	public String getRawTextValue()
	{
		return m_value.m_value;
	}
	
	public String getTextValue()
	{
		return m_value == null ? null : fixString(m_value.m_value);
	}

	public static Swush array(String name, String ... array)
	{
		Swush swush = new Swush(name);
		for (String s : array)
		{
			swush.add(new Swush(s));
		}
		return swush;
	}

	public String[] asArray()
	{
		if (!isNode()) return new String[0];
		List<String> res = new ArrayList<String>();
		for(Swush s : m_children)
		{
			res.add(s.getName());
		}
		
		return (String[]) res.toArray(new String[res.size()]);
	}
	
	
	public void save(String fileName, String encoding) throws IOException
	{
		FileOutputStream fout = new FileOutputStream(fileName);
		try
		{
			save(fout, encoding);
		}
		finally
		{
			fout.close();
		}
	}
	
	public void save(OutputStream out, String encoding) throws IOException
	{
		String str = "@swush 1.0 " + encoding + "\n\n" + toString();
		out.write(str.getBytes(encoding));
	}
	
	
	public boolean isDefined(String selector)
	{
		return selectFirst(selector) != null;
	}

	public Swush addNode(String name)
	{
		Swush child = Swush.node(name);
		add(child);
		return child;
	}

	public Swush addPair(String name, String value)
	{
		Swush pair = Swush.pair(name, value);
		add(pair);
		return pair;
	}
	
	public Swush addArray(String name, String ... array)
	{
		Swush arr = Swush.array(name, array);
		add(arr);
		return arr;
	}
}
